#include <stdio.h>
#include <stdlib.h>

/*
    Comparing a super simple C program, using glibc vs. a asm64 
    for printing.
*/

int main(void){
    printf("Hello, world!");
    exit(0);
}